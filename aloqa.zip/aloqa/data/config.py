from environs import Env

# environs kutubxonasidan foydalanish
env = Env()
env.read_env()

# .env fayl ichidan quyidagilarni o'qiymiz
BOT_TOKEN = "6563656612:AAExNlgoYxt33JnN9YOUUTLdL_oSVlSNaiM" # Bot toekn
ADMINS = [6326156814,777967425,1074147503,1145605344]  # adminlar ro'yxati
IP = "localhost"  # Xosting ip manzili
