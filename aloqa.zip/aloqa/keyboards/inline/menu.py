from aiogram import types


class Keyboards:
    def main(self):
        menu = types.InlineKeyboardMarkup(row_width=2)
        aloqa = types.InlineKeyboardButton("💬 Adminga Xabar jo'natish", callback_data="habar")
        userbt = types.InlineKeyboardButton("⭐️ UserBot", url="https://t.me/pctermux_linux/3")
        btm = types.InlineKeyboardButton("🤖 Bizning Bot", url="https://t.me/foydali_dastur_kitobbot")
        kanl = types.InlineKeyboardButton("📎 Bizning Kanal", url="https://t.me/windowsuzprogrammaa")
        
        menu.add(aloqa, userbt)
        menu.add(btm, kanl)
        
        return menu


    def contact(self):
        menu = types.ReplyKeyboardMarkup(resize_keyboard=True)
        contact = types.KeyboardButton("Raqamni yuborish 📞", request_contact = True)
        return menu.add(contact)

    def city(self):
        menu = types.InlineKeyboardMarkup(row_width=2)
        Fargona = types.InlineKeyboardButton("Fargona",callback_data="Fargona")
        Andijon = types.InlineKeyboardButton("Andijon",callback_data="Andijon")
        Namangan = types.InlineKeyboardButton("Namangan",callback_data="Namangan")
        Toshkent = types.InlineKeyboardButton("Toshkent",callback_data="Toshkent")
        Sirdaryo = types.InlineKeyboardButton("Sirdaryo",callback_data="Sirdaryo")
        Jizzah = types.InlineKeyboardButton("Jizzah",callback_data="Jizzah")
        Samarqand = types.InlineKeyboardButton("Samarqand",callback_data="Samarqand")
        Navoiy = types.InlineKeyboardButton("Navoiy",callback_data="Navoiy")
        Buxoro = types.InlineKeyboardButton("Buxoro",callback_data="Buxoro")
        Xorazm = types.InlineKeyboardButton("Xorazm",callback_data="Xorazm")
        Qashqadaryo = types.InlineKeyboardButton("Qashqadaryo",callback_data="Qashqadaryo")
        Surxondaryo = types.InlineKeyboardButton("Surxondaryo",callback_data="Surxondaryo")
        return menu.add(Fargona,Andijon,Namangan,Toshkent,Sirdaryo,Jizzah,Samarqand,Navoiy,Buxoro,Xorazm,Qashqadaryo,Surxondaryo)

    def back(self):
        menu = types.ReplyKeyboardMarkup(row_width=1, resize_keyboard = True, one_time_keyboard = True)
        orq = types.KeyboardButton("Orqaga")
        return menu.add(orq)
kb = Keyboards()
